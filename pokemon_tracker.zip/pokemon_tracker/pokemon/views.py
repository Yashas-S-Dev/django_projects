from django.shortcuts import render, get_object_or_404, redirect
from .models import Pokemon
from .forms import PokemonForm

def home(request):
    pokemons = Pokemon.objects.all()
    return render(request, 'pokemon/home.html', {'pokemons': pokemons})

def pokemon_detail(request, pokemon_id):
    pokemon = get_object_or_404(Pokemon, id=pokemon_id)
    return render(request, 'pokemon/pokemon_detail.html', {'pokemon': pokemon})

def add_pokemon(request):
    if request.method == 'POST':
        form = PokemonForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = PokemonForm()
    return render(request, 'pokemon/add_pokemon.html', {'form': form})
