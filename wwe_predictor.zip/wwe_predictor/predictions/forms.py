from django import forms
from .models import Match

class MatchPredictionForm(forms.ModelForm):
    class Meta:
        model = Match
        fields = ['match_title', 'competitor_one', 'competitor_two', 'prediction']
