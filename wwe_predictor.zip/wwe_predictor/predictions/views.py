from django.shortcuts import render, redirect
from .models import Match
from .forms import MatchPredictionForm

def home(request):
    matches = Match.objects.all()
    return render(request, 'predictions/home.html', {'matches': matches})

def add_prediction(request):
    if request.method == 'POST':
        form = MatchPredictionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = MatchPredictionForm()
    return render(request, 'predictions/add_prediction.html', {'form': form})
